import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

import "./index.css";

import { RouterProvider } from "react-router";

import router from "./Routes/Router";

import AuthProvider from "./Providers/AuthProvider/AuthProvider";

import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

// create query client
const queryClient = new QueryClient();

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <RouterProvider router={router} />
      </AuthProvider>
    </QueryClientProvider>
  </StrictMode>,
);
